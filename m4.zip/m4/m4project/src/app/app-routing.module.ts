import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TsaksComponent } from './tsaks/tsaks.component';
import { AddTaskComponent } from './add-task/add-task.component';


const routes: Routes = [
  {path:'newtask', component:AddTaskComponent},
  {path:'task', component:TsaksComponent},
  {path:'', redirectTo: 'task', pathMatch:'full'},
  {path:'**', redirectTo: 'task'},




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
