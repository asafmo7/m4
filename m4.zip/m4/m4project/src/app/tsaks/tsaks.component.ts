import { Component, OnInit } from '@angular/core';
import {TsasksService} from '../tsasks.service';




@Component({
  selector: 'app-tsaks',
  templateUrl: './tsaks.component.html',
  styleUrls: ['./tsaks.component.css']
})
export class TsaksComponent implements OnInit {

  constructor(public TsasksService:TsasksService) { }
public mytasks 
  ngOnInit() {
    this.TsasksService.getTasks().subscribe(
      res =>{console.log(res),
      this.mytasks = res}
    )
  }
  
}

