import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TsaksComponent } from './tsaks.component';

describe('TsaksComponent', () => {
  let component: TsaksComponent;
  let fixture: ComponentFixture<TsaksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TsaksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TsaksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
