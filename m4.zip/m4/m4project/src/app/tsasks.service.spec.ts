import { TestBed } from '@angular/core/testing';

import { TsasksService } from './tsasks.service';

describe('TsasksService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TsasksService = TestBed.get(TsasksService);
    expect(service).toBeTruthy();
  });
});
