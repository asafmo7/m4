import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http'


@Injectable({
  providedIn: 'root'
})
export class TsasksService {
public mytasks
  constructor(public http: HttpClient) { }

  public getTasks() {

    return this.http.get('http://localhost:3000/tasks')
  }


public AddTask(task) {
  console.log("new task work")
  return this.http.post('http://localhost:3000/newtask', task)
}

}