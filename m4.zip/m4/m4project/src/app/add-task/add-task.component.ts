import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { TsasksService } from '../tsasks.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
 
export class AddTaskComponent implements OnInit {
  public mytasks;
 
  constructor(public ts: TsasksService) { }

  ngOnInit() {
    this.mytasks = new FormGroup({
        
      description: new FormControl(""),
      name: new FormControl(""),
      date: new FormControl(""),
    

    })
  }

  public AddTask(){
    console.log(this.mytasks.value)
    this.ts.AddTask(this.mytasks.value).subscribe(
     res=>console.log(res),
      err=>console.log(err)
    )
  }
  }
