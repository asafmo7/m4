let express = require('express');
let mongoose = require('mongoose');
let app = express();
let cors = require('cors')
app.use(express.json())
app.use(cors())

mongoose.connect('mongodb://localhost:27017/tasks',
 { useNewUrlParser: true, useUnifiedTopology: true })
    .then(_ => console.log("connected to mongo db"))
    .catch(err => console.log(err))

    let TaskSchema = new mongoose.Schema({
        description:String,
        name:String,
        date:Date,
        year:Number
    })
    let famliySchema = new mongoose.Schema({
        name:String,
        nick:String,
        description:String,
    })
    
let TaskModel = mongoose.model('tastTable', TaskSchema)
let famliyModel = mongoose.model('famliyTable', famliySchema)


app.get('/tasks', (req, res) => {
    TaskModel.find()
    .then(data=>{
        console.log(data)
        res.json(data)
    })
})
app.get('/famliyMember', (req, res) => {
    famliyModel.find()
    .then(data=>{
        console.log(data)
        res.json(data)
    })
})

app.post('/newtask', (req, res) => {
    console.log(req.body)
    let task = new TaskModel({ _id ,description, name, date, year}=req.body)
    task.save()
    res.json(task)
})
app.post('/newfamliy', (req, res) => {
    console.log(req.body)
    let famliyMember = new famliyModel({_id , name, nick, description}=req.body)
    famliyMember.save()
    res.json(famliyMember)
})





app.listen(3000 , ()=> console.log('serever is on port 3000'))
